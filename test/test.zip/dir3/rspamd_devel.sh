#!/bin/bash

# Start VirtualBox machine
VBoxManage startvm Ubuntu --type headless

# Wait 15 seconds
sleep 20

# Get IP address
ipv4=`VBoxManage guestproperty get Ubuntu "/VirtualBox/GuestInfo/Net/0/V4/IP" | cut -f2 -d" "`

# Add IP in hosts
sudo cp /etc/hosts.bak /etc/hosts
echo "$ipv4 ubuntu" | sudo tee --append /etc/hosts

# Mount rspamd directory
sudo umount devel/rspamd
sshfs root@ubuntu:/root/rspamd ~/devel/rspamd

# Start Atom
atom

# Connect over ssh
ssh root@ubuntu
